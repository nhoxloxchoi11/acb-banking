#!/bin/bash

# Pre-deployment check script for ACB Banking on Vietnam VPS
# Run this before the main deployment script

set -e

echo "🔍 ACB Banking - Pre-deployment Check for Vietnam VPS"
echo "====================================================="

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_check() {
    echo -e "${BLUE}[CHECK]${NC} $1"
}

print_pass() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

print_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Track checks
CHECKS_PASSED=0
CHECKS_FAILED=0

# Function to run a check
run_check() {
    local name="$1"
    local command="$2"
    
    print_check "$name"
    if eval "$command" >/dev/null 2>&1; then
        print_pass "$name"
        ((CHECKS_PASSED++))
    else
        print_fail "$name"
        ((CHECKS_FAILED++))
    fi
}

echo ""
echo "🖥️  System Requirements Check:"
echo "-----------------------------"

# Basic system checks
run_check "Operating System (Ubuntu)" "grep -q Ubuntu /etc/os-release"
run_check "64-bit architecture" "uname -m | grep -q x86_64"
run_check "Minimum RAM (512MB)" "[ $(free -m | awk 'NR==2{print $2}') -ge 512 ]"
run_check "Available disk space (2GB)" "[ $(df / | awk 'NR==2{print $4}') -ge 2097152 ]"
run_check "Internet connectivity" "ping -c 1 google.com"

echo ""
echo "🔧 Required Tools Check:"
echo "------------------------"

# Check if tools exist or can be installed
run_check "curl command" "command -v curl"
run_check "wget command" "command -v wget"
run_check "apt package manager" "command -v apt"
run_check "sudo privileges" "sudo -n true"

echo ""
echo "🌐 Network & DNS Check:"
echo "-----------------------"

# Network checks specific to Vietnam
run_check "DNS resolution" "nslookup thuanday.io.vn 8.8.8.8"
run_check "HTTPS connectivity" "curl -s https://google.com"
run_check "NPM registry access" "curl -s https://registry.npmjs.org/"
run_check "Vietnam NPM mirror access" "curl -s https://registry.npmmirror.com/"

echo ""
echo "📂 Project Files Check:"
echo "-----------------------"

# Check required files
required_files=(
    "package.json"
    "qr-test.js"
    "nginx.conf"
    "ecosystem.config.js"
    "public/index.html"
    "public/qr-payment.html"
)

for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        print_pass "Found $file"
        ((CHECKS_PASSED++))
    else
        print_fail "Missing $file"
        ((CHECKS_FAILED++))
    fi
done

echo ""
echo "🔐 Security Prerequisites:"
echo "-------------------------"

# Check security requirements
run_check "UFW package available" "apt list ufw 2>/dev/null | grep -q ufw"
run_check "Fail2ban package available" "apt list fail2ban 2>/dev/null | grep -q fail2ban"
run_check "OpenSSL available" "command -v openssl"

echo ""
echo "📊 Pre-deployment Summary:"
echo "=========================="

total_checks=$((CHECKS_PASSED + CHECKS_FAILED))
success_rate=$((CHECKS_PASSED * 100 / total_checks))

echo "Total Checks: $total_checks"
echo -e "Passed: ${GREEN}$CHECKS_PASSED${NC}"
echo -e "Failed: ${RED}$CHECKS_FAILED${NC}"
echo "Success Rate: $success_rate%"

echo ""

if [ $CHECKS_FAILED -eq 0 ]; then
    echo -e "${GREEN}🎉 All checks passed! Ready for deployment.${NC}"
    echo ""
    echo "Next steps:"
    echo "1. chmod +x deploy-ubuntu.sh"
    echo "2. ./deploy-ubuntu.sh"
    echo ""
    exit 0
elif [ $success_rate -ge 80 ]; then
    echo -e "${YELLOW}⚠️  Most checks passed. Deployment should work but monitor for issues.${NC}"
    echo ""
    echo "You can proceed with deployment:"
    echo "1. chmod +x deploy-ubuntu.sh"
    echo "2. ./deploy-ubuntu.sh"
    echo ""
    exit 0
else
    echo -e "${RED}❌ Too many checks failed. Please fix issues before deployment.${NC}"
    echo ""
    echo "Common fixes:"
    echo "- Update system: sudo apt update && sudo apt upgrade"
    echo "- Install missing tools: sudo apt install curl wget"
    echo "- Check internet connection"
    echo "- Verify you're running on Ubuntu"
    echo ""
    exit 1
fi 