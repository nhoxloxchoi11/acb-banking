// Login Page JavaScript
const loginForm = document.getElementById('loginForm');
const loginBtn = document.getElementById('loginBtn');
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('password');
const errorModal = document.getElementById('errorModal');
const errorMessage = document.getElementById('errorMessage');

// Toggle password visibility
togglePassword.addEventListener('click', function() {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    
    const icon = this.querySelector('i');
    if (type === 'password') {
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    } else {
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    }
});

// Form submission
loginForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(loginForm);
    const username = formData.get('username').trim();
    const password = formData.get('password');
    
    if (!username || !password) {
        showError('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');
        return;
    }
    
    // Show loading state
    setLoadingState(true);
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username,
                password
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Success - redirect to main page
            showSuccess();
            setTimeout(() => {
                window.location.href = '/';
            }, 1500);
        } else {
            showError(result.message || 'Đăng nhập thất bại');
        }
        
    } catch (error) {
        console.error('Login error:', error);
        showError('Lỗi kết nối. Vui lòng thử lại sau.');
    } finally {
        setLoadingState(false);
    }
});

// Loading state management
function setLoadingState(loading) {
    const btnSpan = loginBtn.querySelector('span');
    const btnIcon = loginBtn.querySelector('i:not(.fa-spinner)');
    const loadingSpinner = loginBtn.querySelector('.loading-spinner');
    
    if (loading) {
        loginBtn.classList.add('loading');
        loginBtn.disabled = true;
        btnSpan.style.display = 'none';
        btnIcon.style.display = 'none';
        loadingSpinner.style.display = 'block';
    } else {
        loginBtn.classList.remove('loading');
        loginBtn.disabled = false;
        btnSpan.style.display = 'inline';
        btnIcon.style.display = 'inline';
        loadingSpinner.style.display = 'none';
    }
}

// Error handling
function showError(message) {
    errorMessage.textContent = message;
    errorModal.style.display = 'block';
    
    // Auto close after 5 seconds
    setTimeout(() => {
        closeError();
    }, 5000);
}

function closeError() {
    errorModal.style.display = 'none';
}

// Success handling
function showSuccess() {
    // Change button to success state
    const btnSpan = loginBtn.querySelector('span');
    const btnIcon = loginBtn.querySelector('i:not(.fa-spinner)');
    const loadingSpinner = loginBtn.querySelector('.loading-spinner');
    
    loginBtn.style.background = '#28a745';
    btnSpan.textContent = 'Đăng nhập thành công!';
    btnSpan.style.display = 'inline';
    btnIcon.className = 'fas fa-check';
    btnIcon.style.display = 'inline';
    loadingSpinner.style.display = 'none';
}

// Error modal events
document.querySelector('#errorModal .close').addEventListener('click', closeError);

window.addEventListener('click', function(event) {
    if (event.target === errorModal) {
        closeError();
    }
});

// Auto-fill demo credentials (for testing)
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        document.getElementById('username').value = 'lethuan431';
        document.getElementById('password').value = 'ThuanDayNe@201019';
        console.log('🔑 Demo credentials filled');
    }
});

// Check if already logged in
async function checkAuthStatus() {
    try {
        const response = await fetch('/api/auth-status');
        const result = await response.json();
        
        if (result.isAuthenticated) {
            window.location.href = '/';
        }
    } catch (error) {
        console.log('Not authenticated, staying on login page');
    }
}

// Run auth check on page load
checkAuthStatus();

console.log('🔐 Login page ready');
console.log('💡 Tip: Press Ctrl+Shift+D to auto-fill demo credentials'); 