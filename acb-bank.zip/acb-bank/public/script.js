// Global variables
let currentAccountNumber = null;
let transactions = [];

// Authentication and user info management
let isAuthenticated = false;
let currentUser = null;

// DOM elements
const balanceInfo = document.getElementById('balanceInfo');
const transactionsInfo = document.getElementById('transactionsInfo');
const refreshBtn = document.getElementById('refreshBtn');
const refreshTransactionsBtn = document.getElementById('refreshTransactionsBtn');
const transactionLimit = document.getElementById('transactionLimit');
const lastUpdated = document.getElementById('lastUpdated');
const errorModal = document.getElementById('errorModal');
const errorMessage = document.getElementById('errorMessage');
const closeModal = document.querySelector('.close');

// Statistics elements
const totalIncome = document.getElementById('totalIncome');
const totalExpense = document.getElementById('totalExpense');
const transactionCount = document.getElementById('transactionCount');

// Event listeners
document.addEventListener('DOMContentLoaded', init);
if (refreshBtn) refreshBtn.addEventListener('click', loadBalance);
if (refreshTransactionsBtn) refreshTransactionsBtn.addEventListener('click', loadTransactions);
if (transactionLimit) transactionLimit.addEventListener('change', loadTransactions);
if (closeModal) closeModal.addEventListener('click', hideError);

// Initialize app
async function init() {
    console.log('🚀 Khởi động ACB Banking Web App...');
    await checkAuthStatus();
}

// Check authentication status on page load
async function checkAuthStatus() {
    try {
        const response = await fetch('/api/auth-status');
        const result = await response.json();
        
        if (result.isAuthenticated) {
            isAuthenticated = true;
            currentUser = result.username;
            showUserInfo(result.username);
            // Initialize the app
            initializeApp();
        } else {
            // Redirect to login if not authenticated
            window.location.href = '/login';
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        // Redirect to login on error
        window.location.href = '/login';
    }
}

// Show user info in header
function showUserInfo(username) {
    const userInfo = document.getElementById('userInfo');
    const usernameDisplay = document.getElementById('usernameDisplay');
    
    if (userInfo && usernameDisplay) {
        usernameDisplay.textContent = username;
        userInfo.style.display = 'flex';
        
        // Add logout event listener
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', handleLogout);
        }
    }
}

// Handle logout
async function handleLogout() {
    try {
        const response = await fetch('/api/logout', {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Redirect to login page
            window.location.href = '/login';
        } else {
            showError('Lỗi khi đăng xuất');
        }
    } catch (error) {
        console.error('Logout error:', error);
        showError('Lỗi kết nối khi đăng xuất');
    }
}

// Initialize app after authentication
function initializeApp() {
    // Start data loading - load balance first, then transactions
    loadBalance().then(() => {
        // Load transactions after balance is loaded to get currentAccountNumber
        loadTransactions();
    });
    
    setupEventListeners();
    
    // Auto refresh every 30 seconds
    setInterval(() => {
        if (isAuthenticated && currentAccountNumber) {
            loadBalance();
            loadTransactions();
        }
    }, 30000);
}

// Setup event listeners
function setupEventListeners() {
    // Existing event listeners
    const refreshBtn = document.getElementById('refreshBtn');
    const refreshTransactionsBtn = document.getElementById('refreshTransactionsBtn');
    const transactionLimit = document.getElementById('transactionLimit');
    
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            addRefreshAnimation(refreshBtn);
            loadBalance().then(() => loadTransactions());
        });
    }
    
    if (refreshTransactionsBtn) {
        refreshTransactionsBtn.addEventListener('click', () => {
            addRefreshAnimation(refreshTransactionsBtn);
            loadTransactions();
        });
    }
    
    if (transactionLimit) {
        transactionLimit.addEventListener('change', loadTransactions);
    }
}

// API call wrapper with auth check
async function authenticatedFetch(url, options = {}) {
    try {
        const response = await fetch(url, {
            ...options,
            credentials: 'include' // Include session cookies
        });
        
        if (response.status === 401) {
            // Unauthorized - redirect to login
            window.location.href = '/login';
            return null;
        }
        
        return response;
    } catch (error) {
        console.error('API call failed:', error);
        throw error;
    }
}

// Load balance information
async function loadBalance() {
    const balanceInfo = document.getElementById('balanceInfo');
    
    if (!balanceInfo) return;
    
    balanceInfo.innerHTML = `
        <div class="loading">
            <i class="fas fa-spinner fa-spin"></i>
            <span>Đang tải thông tin tài khoản...</span>
        </div>
    `;
    
    try {
        const response = await authenticatedFetch('/api/balance');
        if (!response) return;
        
        const data = await response.json();
        
        if (data.success && data.data) {
            displayBalance(data.data);
        } else {
            balanceInfo.innerHTML = `
                <div class="error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>${data.message || 'Không thể tải thông tin tài khoản'}</span>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading balance:', error);
        balanceInfo.innerHTML = `
            <div class="error">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Lỗi kết nối. Vui lòng thử lại.</span>
            </div>
        `;
    }
    
    updateLastUpdated();
}

// Load transactions - Fixed to use currentAccountNumber
async function loadTransactions() {
    if (!isAuthenticated) return;
    
    const transactionsInfo = document.getElementById('transactionsInfo');
    const transactionLimit = document.getElementById('transactionLimit');
    
    if (!transactionsInfo) return;
    
    // Wait for currentAccountNumber to be available
    if (!currentAccountNumber) {
        console.log('Waiting for account number...');
        setTimeout(loadTransactions, 1000);
        return;
    }
    
    const limit = transactionLimit ? transactionLimit.value : 20;
    
    transactionsInfo.innerHTML = `
        <div class="loading">
            <i class="fas fa-spinner fa-spin"></i>
            <span>Đang tải lịch sử giao dịch...</span>
        </div>
    `;
    
    try {
        const response = await authenticatedFetch(`/api/transactions/${currentAccountNumber}?rows=${limit}`);
        if (!response) return;
        
        const data = await response.json();
        
        if (data.success && data.data) {
            displayTransactions(data.data);
            updateStatistics(data.data);
        } else {
            transactionsInfo.innerHTML = `
                <div class="error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>${data.message || 'Không thể tải lịch sử giao dịch'}</span>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading transactions:', error);
        transactionsInfo.innerHTML = `
            <div class="error">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Lỗi kết nối. Vui lòng thử lại.</span>
            </div>
        `;
    }
}

// Display balance information
function displayBalance(balanceData) {
    const balanceInfo = document.getElementById('balanceInfo');
    
    console.log('Displaying balance data:', balanceData);
    
    // Handle different data formats
    let balances = [];
    
    if (balanceData.balances && Array.isArray(balanceData.balances)) {
        balances = balanceData.balances;
    } else if (Array.isArray(balanceData)) {
        balances = balanceData;
    } else if (balanceData.accountNumber) {
        balances = [balanceData];
    } else {
        console.error('Invalid balance data format:', balanceData);
        balanceInfo.innerHTML = `
            <div class="error">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Định dạng dữ liệu số dư không hợp lệ</span>
            </div>
        `;
        return;
    }
    
    if (balances.length > 0) {
        const balance = balances[0];
        currentAccountNumber = balance.accountNumber || '11381077'; // Set the account number here
        
        // Ensure we have valid data
        const accountOwner = balance.accountOwner || balance.owner || 'Không xác định';
        const accountNumber = balance.accountNumber || '11381077';
        const availableBalance = parseFloat(balance.availableBalance) || 0;
        const currentBalance = parseFloat(balance.currentBalance) || availableBalance;
        
        console.log('Processing balance:', {
            accountOwner,
            accountNumber,
            availableBalance,
            currentBalance
        });
        
        balanceInfo.innerHTML = `
            <div class="account-details">
                <div class="account-item">
                    <span class="label"><i class="fas fa-user"></i> Chủ tài khoản:</span>
                    <span class="value">${accountOwner}</span>
                </div>
                <div class="account-item">
                    <span class="label"><i class="fas fa-credit-card"></i> Số tài khoản:</span>
                    <span class="value">${accountNumber}</span>
                </div>
                <div class="account-item">
                    <span class="label"><i class="fas fa-university"></i> Ngân hàng:</span>
                    <span class="value">ACB - Ngân hàng Á Châu</span>
                </div>
                <div class="account-item">
                    <span class="label"><i class="fas fa-wallet"></i> Số dư khả dụng:</span>
                    <span class="value balance-amount">${formatCurrency(availableBalance)} VND</span>
                </div>
                <div class="account-item">
                    <span class="label"><i class="fas fa-coins"></i> Số dư thực:</span>
                    <span class="value">${formatCurrency(currentBalance)} VND</span>
                </div>
            </div>
        `;
        
        console.log('Current account number set:', currentAccountNumber);
    } else {
        balanceInfo.innerHTML = `
            <div class="error">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Không tìm thấy thông tin tài khoản</span>
            </div>
        `;
    }
}

// Display transactions
function displayTransactions(transactions) {
    const transactionsInfo = document.getElementById('transactionsInfo');
    if (!transactionsInfo) return;
    
    transactionsInfo.innerHTML = '';
    
    if (transactions.length === 0) {
        transactionsInfo.innerHTML = `
            <div class="loading">
                <i class="fas fa-info-circle"></i>
                <span>Không có giao dịch nào trong khoảng thời gian này</span>
            </div>
        `;
        return;
    }
    
    transactions.forEach(transaction => {
        const transactionDiv = document.createElement('div');
        const isIncome = transaction.type === 'IN';
        const transactionClass = isIncome ? 'income' : 'expense';
        const amountPrefix = isIncome ? '+' : '-';
        const typeText = isIncome ? 'Tiền vào' : 'Tiền ra';
        
        transactionDiv.className = `transaction-item ${transactionClass}`;
        
        const date = new Date(transaction.activeDatetime);
        const formattedDate = date.toLocaleString('vi-VN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        
        transactionDiv.innerHTML = `
            <div class="transaction-left">
                <div class="transaction-desc">${transaction.description}</div>
                <div class="transaction-date">
                    <i class="fas fa-calendar"></i> ${formattedDate}
                </div>
                <div class="transaction-id">
                    <i class="fas fa-hashtag"></i> ${transaction.transactionNumber}
                </div>
            </div>
            <div class="transaction-right">
                <div class="transaction-amount ${transactionClass}">
                    ${amountPrefix}${formatCurrency(transaction.amount)} ${transaction.currency}
                </div>
                <div class="transaction-type ${transactionClass}">
                    <i class="fas fa-${isIncome ? 'arrow-down' : 'arrow-up'}"></i> ${typeText}
                </div>
            </div>
        `;
        
        transactionsInfo.appendChild(transactionDiv);
    });
}

// Update statistics
function updateStatistics(transactionData) {
    const totalIncomeEl = document.getElementById('totalIncome');
    const totalExpenseEl = document.getElementById('totalExpense');
    const transactionCountEl = document.getElementById('transactionCount');
    
    if (!totalIncomeEl || !totalExpenseEl || !transactionCountEl) return;
    
    let totalIncome = 0;
    let totalExpense = 0;
    
    transactionData.forEach(transaction => {
        if (transaction.type === 'IN') {
            totalIncome += transaction.amount;
        } else if (transaction.type === 'OUT') {
            totalExpense += transaction.amount;
        }
    });
    
    totalIncomeEl.textContent = formatCurrency(totalIncome);
    totalExpenseEl.textContent = formatCurrency(totalExpense);
    transactionCountEl.textContent = transactionData.length;
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN').format(amount);
}

function showLoading(element, message) {
    element.innerHTML = `
        <div class="loading">
            <i class="fas fa-spinner fa-spin"></i>
            <span>${message}</span>
        </div>
    `;
}

function updateLastUpdated() {
    const lastUpdated = document.getElementById('lastUpdated');
    if (!lastUpdated) return;
    
    const now = new Date();
    const formatted = now.toLocaleString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    lastUpdated.textContent = formatted;
}

function showError(message) {
    const errorMessage = document.getElementById('errorMessage');
    const errorModal = document.getElementById('errorModal');
    
    if (errorMessage && errorModal) {
        errorMessage.textContent = message;
        errorModal.style.display = 'block';
        
        // Auto hide after 5 seconds
        setTimeout(() => {
            hideError();
        }, 5000);
    }
}

function hideError() {
    const errorModal = document.getElementById('errorModal');
    if (errorModal) {
        errorModal.style.display = 'none';
    }
}

// Close modal when clicking outside
window.addEventListener('click', (event) => {
    const errorModal = document.getElementById('errorModal');
    if (event.target === errorModal) {
        hideError();
    }
});

// Add refresh animation
function addRefreshAnimation(button) {
    const icon = button.querySelector('i');
    if (icon) {
        icon.style.animation = 'none';
        setTimeout(() => {
            icon.style.animation = 'spin 1s linear infinite';
        }, 10);
        
        setTimeout(() => {
            icon.style.animation = 'none';
        }, 1000);
    }
}

// Add spin animation for refresh
const style = document.createElement('style');
style.textContent = `
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);

// Add keyboard shortcuts
document.addEventListener('keydown', (event) => {
    if (event.ctrlKey && event.key === 'r') {
        event.preventDefault();
        loadBalance().then(() => loadTransactions());
    }
    
    if (event.key === 'Escape') {
        hideError();
    }
});

console.log('✅ ACB Banking Web App đã được khởi tạo!'); 