// QR Payment JavaScript
let currentPaymentInfo = '';
let currentAmount = 0;
let paymentCheckInterval = null;

// DOM Elements
const qrForm = document.getElementById('qrForm');
const generatorSection = document.getElementById('generatorSection');
const displaySection = document.getElementById('displaySection');
const qrImage = document.getElementById('qrImage');
const displayAmount = document.getElementById('displayAmount');
const displayInfo = document.getElementById('displayInfo');
const paymentStatus = document.getElementById('paymentStatus');
const checkPaymentBtn = document.getElementById('checkPaymentBtn');
const newPaymentBtn = document.getElementById('newPaymentBtn');
const successModal = document.getElementById('successModal');
const errorModal = document.getElementById('errorModal');
const errorMessage = document.getElementById('errorMessage');

// Utility Functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

function showError(message) {
    errorMessage.textContent = message;
    errorModal.style.display = 'block';
}

function closeError() {
    errorModal.style.display = 'none';
}

function showSuccess(transaction) {
    const successMessage = document.getElementById('successMessage');
    const transactionDetails = document.getElementById('transactionDetails');
    
    successMessage.textContent = 'Giao dịch đã được xác nhận thành công!';
    transactionDetails.innerHTML = `
        <div class="transaction-info">
            <p><strong>Số tiền:</strong> ${formatCurrency(transaction.amount)}</p>
            <p><strong>Nội dung:</strong> ${transaction.description}</p>
            <p><strong>Thời gian:</strong> ${transaction.date}</p>
            <p><strong>Mã GD:</strong> ${transaction.transactionNumber}</p>
        </div>
    `;
    
    successModal.style.display = 'block';
    
    // Stop checking for payment
    if (paymentCheckInterval) {
        clearInterval(paymentCheckInterval);
        paymentCheckInterval = null;
    }
}

function closeSuccessModal() {
    successModal.style.display = 'none';
    window.location.href = '/';
}

// Generate QR Code
function generateQRCode(amount, paymentInfo) {
    // VietQR API URL với tham số động
    const accountNumber = '11381077';
    const bankId = '970416'; // ACB bank ID
    const template = 'UOsV4Uh'; // Template mặc định
    
    // Tạo URL với các tham số
    const qrUrl = `https://api.vietqr.io/image/${bankId}-${accountNumber}-${template}.jpg` +
                  `?amount=${amount}&addInfo=${encodeURIComponent(paymentInfo)}`;
    
    return qrUrl;
}

// Form Submit Handler
qrForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(qrForm);
    currentAmount = parseInt(formData.get('amount'));
    currentPaymentInfo = formData.get('paymentInfo').trim();
    
    if (currentAmount <= 0) {
        showError('Vui lòng nhập số tiền hợp lệ');
        return;
    }
    
    if (!currentPaymentInfo) {
        showError('Vui lòng nhập nội dung thanh toán');
        return;
    }
    
    // Generate QR Code
    const qrUrl = generateQRCode(currentAmount, currentPaymentInfo);
    qrImage.src = qrUrl;
    
    // Update display
    displayAmount.textContent = formatCurrency(currentAmount);
    displayInfo.textContent = currentPaymentInfo;
    
    // Show display section
    generatorSection.style.display = 'none';
    displaySection.style.display = 'block';
    
    // Reset payment status
    updatePaymentStatus('waiting');
    
    // Start auto-checking (every 10 seconds)
    startAutoCheck();
});

// Payment Status Update
function updatePaymentStatus(status) {
    const statusElement = paymentStatus;
    
    switch(status) {
        case 'waiting':
            statusElement.className = 'payment-status';
            statusElement.innerHTML = '<i class="fas fa-clock"></i> <span>Đang chờ thanh toán...</span>';
            break;
        case 'checking':
            statusElement.className = 'payment-status';
            statusElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Đang kiểm tra...</span>';
            break;
        case 'success':
            statusElement.className = 'payment-status success';
            statusElement.innerHTML = '<i class="fas fa-check-circle"></i> <span>Đã thanh toán!</span>';
            break;
    }
}

// Check Payment Function
async function checkPayment() {
    try {
        updatePaymentStatus('checking');
        
        // Use public API for payment verification
        const accountNumber = '11381077';
        const url = `/api/public/transactions/verify?accountNumber=${accountNumber}&amount=${currentAmount}&description=${encodeURIComponent(currentPaymentInfo)}&timeWindow=${24 * 60 * 60 * 1000}`;
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error('Không thể kiểm tra giao dịch');
        }
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.message || 'Lỗi khi kiểm tra giao dịch');
        }
        
        if (result.verified && result.transaction) {
            updatePaymentStatus('success');
            showSuccess({
                amount: result.transaction.amount,
                description: result.transaction.description,
                date: new Date(result.transaction.date).toLocaleString('vi-VN'),
                transactionNumber: result.transaction.transactionNumber
            });
        } else {
            updatePaymentStatus('waiting');
        }
        
    } catch (error) {
        console.error('Lỗi kiểm tra thanh toán:', error);
        updatePaymentStatus('waiting');
        showError('Lỗi khi kiểm tra thanh toán: ' + error.message);
    }
}

// Auto Check Payment
function startAutoCheck() {
    // Stop any existing interval
    if (paymentCheckInterval) {
        clearInterval(paymentCheckInterval);
    }
    
    // Start new interval (check every 10 seconds)
    paymentCheckInterval = setInterval(checkPayment, 10000);
}

function stopAutoCheck() {
    if (paymentCheckInterval) {
        clearInterval(paymentCheckInterval);
        paymentCheckInterval = null;
    }
}

// Button Event Listeners
checkPaymentBtn.addEventListener('click', checkPayment);

newPaymentBtn.addEventListener('click', function() {
    stopAutoCheck();
    generatorSection.style.display = 'block';
    displaySection.style.display = 'none';
    qrForm.reset();
});

// Error Modal Close
document.querySelector('#errorModal .close').addEventListener('click', closeError);

// Close modals when clicking outside
window.addEventListener('click', function(event) {
    if (event.target === errorModal) {
        closeError();
    }
    if (event.target === successModal) {
        closeSuccessModal();
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    stopAutoCheck();
});

console.log('🎯 QR Payment đã sẵn sàng!'); 