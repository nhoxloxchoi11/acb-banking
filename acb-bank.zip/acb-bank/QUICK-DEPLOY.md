# 🚀 Quick Deploy Guide - ACB Banking cho VPS Vietnam

> **Hướng dẫn triển khai nhanh trong 5 phút cho VPS tại Việt Nam**

## 🎯 Chuẩn bị

### Yêu cầu VPS tối thiểu:
- **OS:** Ubuntu 18.04+ (khuyến nghị 20.04 LTS)
- **RAM:** 512MB+ (khuyến nghị 1GB+)
- **Disk:** 2GB+ (khuyến nghị 5GB+)
- **Network:** Kết nối internet ổn định

### Nhà cung cấp VPS phổ biến tại VN:
- ✅ **Bizfly Cloud** - bizflycloud.vn
- ✅ **VNG Cloud** - vngcloud.vn  
- ✅ **VNPT Cloud** - vnptcloud.vn
- ✅ **123HOST** - 123host.vn
- ✅ **AZDIGI** - azdigi.com

## ⚡ Triển khai 1 lệnh (Recommended)

### Bước 1: Kết nối VPS
```bash
# SSH vào VPS của bạn
ssh root@your-vps-ip
# hoặc
ssh ubuntu@your-vps-ip
```

### Bước 2: Upload code
```bash
# Cách 1: Git clone (nếu có repository)
git clone https://github.com/your-repo/acb-banking.git
cd acb-banking

# Cách 2: Upload file qua SCP
# Từ máy local chạy:
# scp -r acb-banking/ root@your-vps-ip:/root/

# Cách 3: Download trực tiếp
wget https://github.com/your-repo/acb-banking/archive/main.zip
unzip main.zip
cd acb-banking-main
```

### Bước 3: Chạy installer
```bash
# Chỉ cần 1 lệnh này!
chmod +x install.sh && ./install.sh
```

### Bước 4: Cập nhật DNS
```
Domain: thuanday.io.vn
Type: A Record
Value: [IP-VPS-của-bạn]
```

## ✅ Hoàn thành!

Sau 5-10 phút, ứng dụng sẽ có sẵn tại:
- 🏠 **Dashboard:** https://thuanday.io.vn (đăng nhập)
- 📱 **QR Payment:** https://thuanday.io.vn/qr-thanh-toan (công khai)

**Thông tin đăng nhập:**
- Username: `lethuan431`
- Password: `ThuanDayNe@201019`

---

## 🔧 Triển khai thủ công (Manual)

### Bước 1: Kiểm tra hệ thống
```bash
chmod +x pre-deploy-check.sh
./pre-deploy-check.sh
```

### Bước 2: Triển khai chính
```bash
chmod +x deploy-ubuntu.sh
./deploy-ubuntu.sh
```

---

## 🇻🇳 Tối ưu cho VPS Vietnam

Script tự động:
- ✅ Chọn npm registry nhanh nhất cho VN
- ✅ Sử dụng Ubuntu mirror Việt Nam
- ✅ Cấu hình múi giờ Asia/Ho_Chi_Minh
- ✅ Whitelist IP ranges các ISP VN chính
- ✅ Tối ưu network cho điều kiện VN

---

## 📊 Kiểm tra sau khi cài đặt

```bash
# Kiểm tra trạng thái tổng thể
./status.sh

# Kiểm tra PM2
pm2 status

# Kiểm tra Nginx
sudo systemctl status nginx

# Kiểm tra SSL
curl -I https://thuanday.io.vn

# Xem logs
pm2 logs
```

---

## 🆘 Troubleshooting nhanh

### Lỗi npm timeout:
```bash
npm config set registry https://registry.npmmirror.com/
npm config set timeout 300000
```

### Lỗi SSL:
```bash
sudo certbot --nginx -d thuanday.io.vn
```

### App không start:
```bash
pm2 restart acb-banking
pm2 logs acb-banking
```

### Nginx lỗi:
```bash
sudo nginx -t
sudo systemctl reload nginx
```

### Khởi động lại toàn bộ:
```bash
./install.sh  # Chạy lại installer
```

---

## 💡 Tips cho VPS Vietnam

1. **Chọn datacenter gần:** Hà Nội/HCM để latency thấp
2. **Bandwidth:** Tối thiểu 10Mbps để download nhanh
3. **Provider recommendation:** Bizfly Cloud có tốc độ tốt nhất
4. **Time setup:** Buổi tối (20h-23h) thường có tốc độ download tốt hơn
5. **Backup:** Script tự động backup hàng ngày lúc 2h sáng

---

## 🔥 One-liner cho từng provider

### Bizfly Cloud:
```bash
curl -sSL https://your-repo.com/install.sh | bash
```

### VNG Cloud:
```bash
wget -qO- https://your-repo.com/install.sh | bash
```

### VNPT Cloud:
```bash
bash <(curl -s https://your-repo.com/install.sh)
```

---

**🎉 Xong! Ứng dụng ACB Banking đã sẵn sàng phục vụ!**

**Support:** Chạy `./status.sh` để kiểm tra tình trạng hệ thống 