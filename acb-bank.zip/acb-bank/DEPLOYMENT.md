# 🚀 ACB Banking - Production Deployment Guide

## 📋 Overview

This guide provides comprehensive instructions for deploying the ACB Banking Web Application to production on Ubuntu VPS.

## 🔧 Prerequisites

- Ubuntu 18.04+ VPS with at least 1GB RAM
- Domain name pointed to your VPS IP
- SSH access to your server
- Root or sudo privileges

## 🎯 Quick Deployment (Recommended)

### Method 1: Automated Script

```bash
# 1. Upload project files to VPS
scp -r . user@your-server:/home/user/acb-banking

# 2. SSH to your server
ssh user@your-server

# 3. Navigate to project directory
cd ~/acb-banking

# 4. Run deployment script
chmod +x deploy-ubuntu.sh
./deploy-ubuntu.sh
```

### Method 2: Docker Deployment

```bash
# 1. Clone repository
git clone your-repo-url
cd acb-banking

# 2. Build and run with Docker Compose
docker-compose up -d

# 3. Setup SSL with Let's Encrypt
sudo certbot --nginx -d your-domain.com
```

## 🛠️ Manual Deployment

### Step 1: System Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 2: Install Dependencies

```bash
# Install PM2
sudo npm install -g pm2

# Install Nginx
sudo apt install -y nginx

# Install SSL tools
sudo apt install -y certbot python3-certbot-nginx
```

### Step 3: Application Setup

```bash
# Create app directory
sudo mkdir -p /var/www/acb-banking
sudo chown -R $USER:$USER /var/www/acb-banking

# Copy application files
cp -r . /var/www/acb-banking
cd /var/www/acb-banking

# Install dependencies
npm ci --only=production

# Build TypeScript
npm run build

# Create logs directory
mkdir -p logs
```

### Step 4: Environment Configuration

```bash
# Create environment file
cat > .env << EOL
NODE_ENV=production
PORT=3000
SESSION_SECRET=$(openssl rand -base64 32)
ACB_USERNAME=your_acb_username
ACB_PASSWORD=your_acb_password
EOL
```

### Step 5: PM2 Configuration

```bash
# Setup PM2 startup
pm2 startup
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp /home/$USER

# Start application
pm2 start ecosystem.config.js --env production
pm2 save
```

### Step 6: Nginx Configuration

```bash
# Create Nginx config
sudo nano /etc/nginx/sites-available/acb-banking
```

Copy the configuration from `nginx.conf` file, then:

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/acb-banking /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

# Test and restart
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### Step 7: SSL Certificate

```bash
# Setup Let's Encrypt SSL
sudo certbot --nginx -d your-domain.com -d www.your-domain.com
```

### Step 8: Firewall Configuration

```bash
# Configure UFW
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw --force enable
```

## 🔒 Security Hardening

### 1. Update Default Credentials

⚠️ **IMPORTANT**: Change default login credentials in production:

```javascript
// In qr-test.js, update the users object:
const users = {
    'your_username': {
        password: 'your_hashed_password', // Use bcrypt to hash
        username: 'your_username'
    }
};
```

### 2. Generate Secure Session Secret

```bash
# Generate random session secret
openssl rand -base64 64
```

### 3. Environment Variables

```bash
# Set production environment variables
export NODE_ENV=production
export SESSION_SECRET="your-secure-session-secret"
export ACB_USERNAME="your-acb-username"
export ACB_PASSWORD="your-acb-password"
```

## 📊 Monitoring & Maintenance

### PM2 Process Management

```bash
# Check status
pm2 status

# View logs
pm2 logs acb-banking

# Restart app
pm2 restart acb-banking

# Monitor resources
pm2 monit
```

### Nginx Management

```bash
# Check status
sudo systemctl status nginx

# Restart Nginx
sudo systemctl restart nginx

# Test configuration
sudo nginx -t

# View access logs
sudo tail -f /var/log/nginx/access.log

# View error logs
sudo tail -f /var/log/nginx/error.log
```

### Application Logs

```bash
# View application logs
tail -f /var/www/acb-banking/logs/app.log

# View PM2 logs
pm2 logs acb-banking --lines 100
```

## 🔄 Backup & Recovery

### Automated Backups

The deployment script sets up automated daily backups:

```bash
# Manual backup
cd /var/www/acb-banking
./backup.sh

# View backups
ls -la /var/backups/acb-banking/
```

### Database Backup (if applicable)

```bash
# Backup environment and configs
tar -czf acb-config-backup.tar.gz .env ecosystem.config.js
```

## 🚀 Performance Optimization

### 1. Enable Gzip Compression

Already configured in Nginx config.

### 2. Static File Caching

Configured with 1-year cache for static assets.

### 3. PM2 Cluster Mode

```javascript
// In ecosystem.config.js
instances: 'max', // Uses all CPU cores
exec_mode: 'cluster'
```

### 4. Memory Management

```javascript
// PM2 config includes:
max_memory_restart: '500M'
```

## 🔍 Troubleshooting

### Common Issues

1. **Application won't start**
   ```bash
   pm2 logs acb-banking
   # Check for Node.js version compatibility
   node --version
   ```

2. **Nginx 502 Bad Gateway**
   ```bash
   # Check if app is running
   pm2 status
   
   # Check Nginx config
   sudo nginx -t
   
   # Check if port 3000 is accessible
   curl localhost:3000/health
   ```

3. **SSL Certificate Issues**
   ```bash
   # Renew certificate
   sudo certbot renew
   
   # Check certificate status
   sudo certbot certificates
   ```

4. **Permission Issues**
   ```bash
   # Fix file permissions
   sudo chown -R $USER:$USER /var/www/acb-banking
   chmod +x deploy-ubuntu.sh
   ```

### Health Checks

```bash
# Application health
curl http://your-domain.com/health

# SSL check
curl -I https://your-domain.com

# PM2 status
pm2 status

# Nginx status
sudo systemctl status nginx
```

## 📈 Scaling & Load Balancing

### Horizontal Scaling

For high traffic, consider:

1. **Multiple PM2 instances**
2. **Load balancer (HAProxy/Nginx)**
3. **Database clustering**
4. **CDN for static assets**

### Vertical Scaling

- Increase VPS resources
- Optimize database queries
- Implement Redis caching

## 🔐 Production Security Checklist

- [ ] Changed default login credentials
- [ ] Generated secure session secret
- [ ] Configured SSL/TLS certificates
- [ ] Enabled firewall (UFW)
- [ ] Set up fail2ban for SSH protection
- [ ] Configured rate limiting
- [ ] Set secure HTTP headers
- [ ] Regular security updates
- [ ] Monitor application logs
- [ ] Backup strategy in place

## 📞 Support

### Useful Commands Reference

```bash
# Application Management
pm2 start|stop|restart acb-banking
pm2 logs acb-banking
pm2 monit

# Server Management
sudo systemctl status|restart nginx
sudo ufw status
sudo certbot renew

# Debugging
tail -f /var/www/acb-banking/logs/app.log
curl localhost:3000/health
sudo nginx -t
```

### Emergency Recovery

```bash
# Stop all services
pm2 stop all
sudo systemctl stop nginx

# Restore from backup
cd /var/backups/acb-banking/
tar -xzf latest-backup.tar.gz -C /var/www/acb-banking/

# Restart services
pm2 start all
sudo systemctl start nginx
```

---

**🎉 Your ACB Banking Web Application is now ready for production!**

For additional support, check the logs or contact the development team. 