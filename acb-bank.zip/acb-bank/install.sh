#!/bin/bash

# ACB Banking - One-Command Installer for Vietnam VPS
# Ultimate automation script - just run this one file!

set -e

echo "🚀 ACB Banking - One-Command Vietnam VPS Installer"
echo "=================================================="
echo "🇻🇳 Optimized for Vietnam infrastructure"
echo "⚡ Fully automated deployment"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

print_step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')] 🔄${NC} $1"
}

print_success() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')] ✅${NC} $1"
}

print_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')] ❌${NC} $1"
}

print_info() {
    echo -e "${CYAN}[$(date '+%H:%M:%S')] ℹ️${NC} $1"
}

# Check if we're on Ubuntu
if ! grep -q Ubuntu /etc/os-release 2>/dev/null; then
    print_error "This script is designed for Ubuntu. Other Linux distributions may not work."
    echo "Detected OS: $(cat /etc/os-release | grep PRETTY_NAME | cut -d'"' -f2 2>/dev/null || uname -s)"
    exit 1
fi

print_success "Detected Ubuntu - proceeding with installation"

# Make scripts executable
print_step "Preparing deployment scripts..."
chmod +x pre-deploy-check.sh 2>/dev/null || print_info "pre-deploy-check.sh not found, skipping"
chmod +x deploy-ubuntu.sh 2>/dev/null || {
    print_error "deploy-ubuntu.sh not found! Please ensure the file exists."
    exit 1
}

print_success "Scripts prepared"

# Run pre-deployment check if it exists
if [ -f "pre-deploy-check.sh" ]; then
    print_step "Running pre-deployment checks..."
    if ./pre-deploy-check.sh; then
        print_success "Pre-deployment checks passed"
    else
        print_error "Pre-deployment checks failed"
        echo ""
        echo "Would you like to proceed anyway? (y/N)"
        read -r response
        if [[ ! "$response" =~ ^[Yy]$ ]]; then
            print_info "Deployment cancelled by user"
            exit 1
        fi
        print_info "Proceeding despite failed checks..."
    fi
else
    print_info "Pre-deployment check script not found, proceeding directly"
fi

# Run main deployment
print_step "Starting main deployment process..."
echo ""
echo "🎯 This will install and configure:"
echo "   ✅ Node.js 18.x"
echo "   ✅ PM2 Process Manager"
echo "   ✅ Nginx Web Server"
echo "   ✅ SSL Certificate (Let's Encrypt)"
echo "   ✅ UFW Firewall"
echo "   ✅ Fail2ban Security"
echo "   ✅ Automated Backups"
echo "   ✅ Health Monitoring"
echo "   ✅ Vietnam Network Optimizations"
echo ""

# Countdown for user to cancel
echo "Starting deployment in:"
for i in {5..1}; do
    echo -n "$i... "
    sleep 1
done
echo ""
echo ""

print_step "🚀 Starting automated deployment for thuanday.io.vn"

# Run the main deployment script
if ./deploy-ubuntu.sh; then
    echo ""
    echo "=================================================================="
    print_success "🎉 ACB Banking deployment completed successfully!"
    echo "=================================================================="
    echo ""
    echo "🌐 Your application is now available at:"
    echo "   📱 QR Payment (Public):  https://thuanday.io.vn/qr-thanh-toan"
    echo "   🏠 Dashboard (Protected): https://thuanday.io.vn/"
    echo "   📊 Health Check:         https://thuanday.io.vn/health"
    echo ""
    echo "🔑 Login Credentials:"
    echo "   Username: lethuan431"
    echo "   Password: ThuanDayNe@201019"
    echo ""
    echo "🛠️  Quick Management Commands:"
    echo "   ./status.sh    - Check system status"
    echo "   pm2 logs       - View application logs"
    echo "   pm2 restart all - Restart application"
    echo ""
    echo "📋 Important Notes:"
    echo "   1. Update your DNS A record: thuanday.io.vn → $(curl -s ifconfig.me 2>/dev/null || echo 'YOUR_SERVER_IP')"
    echo "   2. SSL certificate will be configured automatically"
    echo "   3. All services are set to auto-start on reboot"
    echo "   4. Daily backups are scheduled at 2 AM"
    echo ""
    print_success "🇻🇳 Deployment optimized for Vietnam infrastructure!"
    echo "=================================================================="
else
    echo ""
    print_error "Deployment encountered errors"
    echo ""
    echo "🔧 Troubleshooting steps:"
    echo "   1. Check network connectivity: ping google.com"
    echo "   2. Verify sufficient disk space: df -h"
    echo "   3. Check system logs: journalctl -f"
    echo "   4. Try running individual components manually"
    echo ""
    echo "📞 If problems persist:"
    echo "   - Review the error messages above"
    echo "   - Check deploy-ubuntu.sh script for specific failures"
    echo "   - Ensure you have sudo privileges"
    echo ""
    exit 1
fi 