#!/bin/bash

# ACB Banking Web App - Fully Automated Production Deployment for Vietnam VPS
# Optimized for Vietnamese network conditions and infrastructure
# Run with: chmod +x deploy-ubuntu.sh && ./deploy-ubuntu.sh

set -e

echo "🚀 Starting ACB Banking Web App production deployment on Vietnam VPS..."
echo "🌐 Domain: thuanday.io.vn"
echo "🇻🇳 Optimized for Vietnam infrastructure"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Configuration
DOMAIN="thuanday.io.vn"
EMAIL="admin@thuanday.io.vn"
APP_DIR="/var/www/acb-banking"
CURRENT_USER=$(whoami)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Vietnam-optimized registries
VN_NPM_REGISTRIES=(
    "https://registry.npmmirror.com/"
    "https://r.cnpmjs.org/"
    "https://registry.npm.taobao.org/"
    "https://npmreg.proxy.ustclug.org/"
    "https://registry.npmjs.org/"
)

# Function to print colored output with timestamp
print_status() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')] ✅${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')] ⚠️${NC} $1"
}

print_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')] ❌${NC} $1"
}

print_step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')] 🔄${NC} $1"
}

print_success() {
    echo -e "${CYAN}[$(date '+%H:%M:%S')] 🎉${NC} $1"
}

print_info() {
    echo -e "${PURPLE}[$(date '+%H:%M:%S')] ℹ️${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to retry command with exponential backoff
retry_command() {
    local max_attempts=5
    local delay=1
    local attempt=1
    local command="$*"
    
    while [ $attempt -le $max_attempts ]; do
        print_info "Attempt $attempt/$max_attempts: $command"
        if eval "$command"; then
            return 0
        fi
        
        if [ $attempt -lt $max_attempts ]; then
            print_warning "Command failed, retrying in ${delay}s..."
            sleep $delay
            delay=$((delay * 2))
        fi
        attempt=$((attempt + 1))
    done
    
    print_error "Command failed after $max_attempts attempts: $command"
    return 1
}

# Function to test npm registry speed
test_registry_speed() {
    local registry=$1
    local start_time=$(date +%s%N)
    
    if timeout 10 npm ping --registry="$registry" >/dev/null 2>&1; then
        local end_time=$(date +%s%N)
        local duration=$(( (end_time - start_time) / 1000000 ))
        echo $duration
    else
        echo 99999
    fi
}

# Function to find fastest npm registry for Vietnam
find_fastest_registry() {
    print_step "Testing npm registries speed for Vietnam..."
    local fastest_registry=""
    local fastest_time=99999
    
    for registry in "${VN_NPM_REGISTRIES[@]}"; do
        print_info "Testing registry: $registry"
        local time=$(test_registry_speed "$registry")
        
        if [ "$time" -lt "$fastest_time" ]; then
            fastest_time=$time
            fastest_registry=$registry
        fi
    done
    
    if [ -n "$fastest_registry" ]; then
        print_success "Fastest registry: $fastest_registry (${fastest_time}ms)"
        echo "$fastest_registry"
    else
        print_warning "Using default registry"
        echo "https://registry.npmjs.org/"
    fi
}

# Function to setup user if running as root
setup_user() {
    if [[ $EUID -eq 0 ]]; then
        print_warning "Running as root. Creating deployment user..."
        
        # Create deployment user if not exists
        if ! id "deploy" &>/dev/null; then
            useradd -m -s /bin/bash -G sudo deploy
            echo "deploy:$(openssl rand -base64 32)" | chpasswd
            print_status "Created user 'deploy'"
        fi
        
        # Copy script to deploy user and continue as deploy
        cp "$0" /home/deploy/
        chown deploy:deploy /home/deploy/$(basename "$0")
        chmod +x /home/deploy/$(basename "$0")
        
        print_info "Switching to deploy user..."
        exec sudo -u deploy /home/deploy/$(basename "$0") "$@"
    fi
}

# Function to update system with Vietnam optimizations
update_system() {
    print_step "Updating system packages with Vietnam mirror optimization..."
    
    # Use Vietnam Ubuntu mirrors for faster downloads
    sudo tee /etc/apt/sources.list > /dev/null << 'EOL'
# Vietnam Ubuntu Mirrors for faster downloads
deb http://vn.archive.ubuntu.com/ubuntu/ $(lsb_release -cs) main restricted universe multiverse
deb http://vn.archive.ubuntu.com/ubuntu/ $(lsb_release -cs)-updates main restricted universe multiverse
deb http://vn.archive.ubuntu.com/ubuntu/ $(lsb_release -cs)-security main restricted universe multiverse
deb http://vn.archive.ubuntu.com/ubuntu/ $(lsb_release -cs)-backports main restricted universe multiverse
EOL
    
    # Update with retries
    retry_command "sudo apt update"
    retry_command "sudo DEBIAN_FRONTEND=noninteractive apt upgrade -y"
    
    print_status "System updated successfully"
}

# Function to install dependencies with automatic error handling
install_dependencies() {
    print_step "Installing dependencies with automatic error handling..."
    
    # Install essential packages
    local packages=(
        "curl" "wget" "gnupg2" "software-properties-common" 
        "ufw" "fail2ban" "unattended-upgrades" "apt-listchanges"
        "htop" "iotop" "iftop" "ncdu" "tree" "jq" "bc"
        "nginx" "certbot" "python3-certbot-nginx"
        "build-essential" "git"
    )
    
    for package in "${packages[@]}"; do
        if ! dpkg -l | grep -q "^ii  $package "; then
            retry_command "sudo DEBIAN_FRONTEND=noninteractive apt install -y $package"
        else
            print_info "$package already installed"
        fi
    done
    
    print_status "Dependencies installed successfully"
}

# Function to install Node.js with multiple fallback methods
install_nodejs() {
    print_step "Installing Node.js 18.x with Vietnam optimizations..."
    
    if command_exists node && node --version | grep -q "v18"; then
        print_info "Node.js 18.x already installed: $(node --version)"
        return 0
    fi
    
    # Method 1: NodeSource repository (fastest for Vietnam)
    if ! command_exists node; then
        print_info "Installing Node.js via NodeSource repository..."
        if retry_command "curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -"; then
            retry_command "sudo apt-get install -y nodejs"
        fi
    fi
    
    # Method 2: snap as fallback
    if ! command_exists node; then
        print_warning "Fallback to snap installation..."
        retry_command "sudo snap install node --classic"
    fi
    
    # Method 3: binary download as last resort
    if ! command_exists node; then
        print_warning "Fallback to binary installation..."
        cd /tmp
        wget https://nodejs.org/dist/v18.19.0/node-v18.19.0-linux-x64.tar.xz
        tar -xf node-v18.19.0-linux-x64.tar.xz
        sudo cp -r node-v18.19.0-linux-x64/* /usr/local/
        rm -rf node-v18.19.0-linux-x64*
    fi
    
    # Verify installation
    if command_exists node; then
        print_success "Node.js installed: $(node --version)"
        print_success "NPM installed: $(npm --version)"
    else
        print_error "Failed to install Node.js"
        exit 1
    fi
}

# Function to install PM2 with optimizations
install_pm2() {
    print_step "Installing PM2 process manager..."
    
    if command_exists pm2; then
        print_info "PM2 already installed: $(pm2 --version)"
        return 0
    fi
    
    # Find fastest registry
    local fastest_registry=$(find_fastest_registry)
    
    # Install PM2 globally with retry
    retry_command "sudo npm install -g pm2 --registry=$fastest_registry"
    
    print_status "PM2 installed successfully"
}

# Function to setup application directory and files
setup_application() {
    print_step "Setting up application directory and files..."
    
    # Create application directory
    sudo mkdir -p $APP_DIR
    sudo chown -R $CURRENT_USER:$CURRENT_USER $APP_DIR
    
    # Navigate to app directory
    cd $APP_DIR
    
    # Copy application files intelligently
    print_info "Copying application files from $SCRIPT_DIR..."
    
    # Copy all files except development directories
    rsync -av \
        --exclude='node_modules' \
        --exclude='logs' \
        --exclude='.git' \
        --exclude='ACB-main' \
        --exclude='.idea' \
        --exclude='src' \
        --exclude='typings' \
        --exclude='.github' \
        --exclude='HUONG_DAN*.md' \
        --exclude='QUICK_START.md' \
        --exclude='test-*.js' \
        --exclude='update_server.txt' \
        --exclude='acb-website.png' \
        $SCRIPT_DIR/ .
    
    # Create necessary directories
    mkdir -p logs
    mkdir -p dist
    
    print_status "Application files setup completed"
}

# Function to install npm dependencies with Vietnam optimizations
install_npm_dependencies() {
    print_step "Installing Node.js dependencies with Vietnam optimizations..."
    
    # Find fastest registry
    local fastest_registry=$(find_fastest_registry)
    
    # Configure npm for Vietnam
    npm config set registry "$fastest_registry"
    npm config set timeout 300000
    npm config set network-timeout 300000
    npm config set fetch-retry-mintimeout 20000
    npm config set fetch-retry-maxtimeout 120000
    npm config set fetch-retry-factor 2
    npm config set fetch-retries 5
    
    # Clear npm cache
    npm cache clean --force || true
    
    # Install yarn as backup
    if ! command_exists yarn; then
        print_info "Installing Yarn as backup package manager..."
        curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add - || true
        echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
        sudo apt update && sudo apt install yarn -y || true
        
        if command_exists yarn; then
            yarn config set registry "$fastest_registry"
            yarn config set network-timeout 300000
        fi
    fi
    
    # Try multiple installation methods
    local install_success=false
    
    # Method 1: npm ci
    if [ -f "package-lock.json" ] && ! $install_success; then
        print_info "Attempting npm ci installation..."
        if retry_command "npm ci --only=production --timeout=300000"; then
            install_success=true
        fi
    fi
    
    # Method 2: npm install
    if ! $install_success; then
        print_info "Attempting npm install..."
        if retry_command "npm install --only=production --timeout=300000"; then
            install_success=true
        fi
    fi
    
    # Method 3: yarn install
    if ! $install_success && command_exists yarn; then
        print_info "Attempting yarn install..."
        if retry_command "yarn install --production --network-timeout 300000"; then
            install_success=true
        fi
    fi
    
    # Method 4: Manual package installation
    if ! $install_success; then
        print_warning "Fallback to manual package installation..."
        local essential_packages=("express" "puppeteer" "bcryptjs" "express-session" "helmet" "express-rate-limit")
        
        for package in "${essential_packages[@]}"; do
            retry_command "npm install $package --registry=$fastest_registry"
        done
        install_success=true
    fi
    
    if $install_success; then
        print_status "Dependencies installed successfully"
    else
        print_error "Failed to install dependencies"
        exit 1
    fi
}

# Function to build TypeScript if needed
build_application() {
    if [ -f "tsconfig.json" ]; then
        print_step "Building TypeScript files..."
        if command_exists tsc; then
            npm run build || tsc
        else
            print_info "TypeScript compiler not found, skipping build"
        fi
    fi
}

# Function to setup environment variables
setup_environment() {
    print_step "Setting up production environment variables..."
    
    local session_secret=$(openssl rand -base64 64)
    
    cat > .env << EOL
NODE_ENV=production
PORT=3000
SESSION_SECRET=$session_secret
ACB_USERNAME=11381077
ACB_PASSWORD=ThuanDayNe@201019
DOMAIN=$DOMAIN

# Vietnam-specific optimizations
TZ=Asia/Ho_Chi_Minh
LANG=en_US.UTF-8
LC_ALL=en_US.UTF-8

# Performance settings
UV_THREADPOOL_SIZE=128
NODE_OPTIONS="--max-old-space-size=512"
EOL
    
    print_status "Environment variables configured"
}

# Function to configure PM2 with optimizations
configure_pm2() {
    print_step "Configuring PM2 with optimizations..."
    
    # Setup PM2 startup
    pm2 startup systemd -u $CURRENT_USER --hp $(eval echo ~$CURRENT_USER) || true
    sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $CURRENT_USER --hp $(eval echo ~$CURRENT_USER) || true
    
    # Start application with PM2
    if pm2 list | grep -q "acb-banking"; then
        pm2 restart acb-banking
    else
        pm2 start ecosystem.config.js --env production
    fi
    
    pm2 save
    
    print_status "PM2 configured and application started"
}

# Function to configure Nginx with Vietnam optimizations
configure_nginx() {
    print_step "Configuring Nginx with Vietnam optimizations..."
    
    # Backup original config
    sudo cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup || true
    
    # Copy optimized config
    sudo cp nginx.conf /etc/nginx/nginx.conf
    
    # Test nginx configuration
    if sudo nginx -t; then
        print_status "Nginx configuration is valid"
    else
        print_error "Nginx configuration is invalid, restoring backup"
        sudo cp /etc/nginx/nginx.conf.backup /etc/nginx/nginx.conf
        exit 1
    fi
    
    # Restart nginx
    sudo systemctl restart nginx
    sudo systemctl enable nginx
    
    print_status "Nginx configured and started"
}

# Function to configure security with Vietnam considerations
configure_security() {
    print_step "Configuring security with Vietnam-specific settings..."
    
    # Configure UFW firewall
    sudo ufw --force reset
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    sudo ufw allow ssh
    sudo ufw allow 'Nginx Full'
    
    # Allow specific Vietnam IP ranges if needed
    sudo ufw allow from 1.52.0.0/14 comment 'Vietnam Viettel'
    sudo ufw allow from 14.160.0.0/11 comment 'Vietnam VNPT'
    sudo ufw allow from 27.64.0.0/13 comment 'Vietnam FPT'
    
    sudo ufw --force enable
    
    # Configure fail2ban with Vietnam-friendly settings
    sudo tee /etc/fail2ban/jail.local << EOL
[DEFAULT]
bantime = 1800
findtime = 300
maxretry = 5
backend = systemd

# Vietnam-friendly settings
ignoreip = 127.0.0.1/8 ::1 1.52.0.0/14 14.160.0.0/11 27.64.0.0/13

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

[nginx-req-limit]
enabled = true
filter = nginx-req-limit
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 20
EOL
    
    sudo systemctl enable fail2ban
    sudo systemctl restart fail2ban
    
    print_status "Security configured"
}

# Function to setup SSL certificate
setup_ssl() {
    print_step "Setting up SSL certificate for $DOMAIN..."
    
    # Create webroot directory
    sudo mkdir -p /var/www/letsencrypt
    
    # Get SSL certificate with multiple methods
    local ssl_success=false
    
    # Method 1: Webroot
    if ! $ssl_success; then
        print_info "Attempting SSL via webroot method..."
        if sudo certbot certonly --webroot -w /var/www/letsencrypt -d $DOMAIN -d www.$DOMAIN --email $EMAIL --agree-tos --non-interactive; then
            ssl_success=true
        fi
    fi
    
    # Method 2: Standalone (requires stopping nginx temporarily)
    if ! $ssl_success; then
        print_info "Attempting SSL via standalone method..."
        sudo systemctl stop nginx
        if sudo certbot certonly --standalone -d $DOMAIN -d www.$DOMAIN --email $EMAIL --agree-tos --non-interactive; then
            ssl_success=true
        fi
        sudo systemctl start nginx
    fi
    
    # Method 3: DNS challenge (manual)
    if ! $ssl_success; then
        print_warning "Automatic SSL setup failed. You may need to configure DNS manually."
        print_info "Run: sudo certbot --manual --preferred-challenges dns -d $DOMAIN"
    fi
    
    # Setup automatic renewal
    echo "0 12 * * * /usr/bin/certbot renew --quiet" | sudo crontab -
    
    if $ssl_success; then
        print_status "SSL certificate configured"
    else
        print_warning "SSL setup completed with manual steps required"
    fi
}

# Function to setup monitoring and automation
setup_automation() {
    print_step "Setting up monitoring and automation..."
    
    # Create enhanced status script
    cat > status.sh << 'EOL'
#!/bin/bash
# Enhanced status check script for Vietnam deployment

echo "🏦 ACB Banking Production Status - Vietnam VPS"
echo "==============================================="
echo "🌐 Domain: thuanday.io.vn"
echo "🇻🇳 Location: Vietnam"
echo "⏰ Time: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

echo "📊 Application Status:"
pm2 status 2>/dev/null || echo "PM2 not running"

echo ""
echo "🔧 System Info:"
echo "CPU: $(cat /proc/loadavg)"
echo "Memory: $(free -h | grep Mem | awk '{print $3"/"$2" ("$3/$2*100"%)"}')"
echo "Disk: $(df -h / | awk 'NR==2{print $5 " used (" $3"/"$2 ")"}')"
echo "Uptime: $(uptime -p)"

echo ""
echo "🌐 Network & Services:"
echo "Nginx: $(sudo systemctl is-active nginx 2>/dev/null || echo 'inactive')"
echo "PM2: $(pm2 ping 2>/dev/null || echo 'inactive')"
echo "SSL: $(sudo certbot certificates 2>/dev/null | grep -A2 thuanday.io.vn | tail -1 | awk '{print $3}' || echo 'Not configured')"

echo ""
echo "🔐 Security Status:"
echo "UFW: $(sudo ufw status | head -1)"
echo "Fail2ban: $(sudo systemctl is-active fail2ban 2>/dev/null || echo 'inactive')"

echo ""
echo "🇻🇳 Vietnam Network Optimizations:"
echo "NPM Registry: $(npm config get registry)"
echo "Timezone: $(timedatectl | grep 'Time zone' | awk '{print $3}')"

echo ""
echo "📈 Performance:"
if command -v pm2 >/dev/null 2>&1; then
    pm2 show acb-banking 2>/dev/null | grep -E "(memory|cpu)" || echo "App metrics unavailable"
fi
EOL
    
    chmod +x status.sh
    
    # Create backup script
    cat > backup.sh << 'EOL'
#!/bin/bash
# Enhanced backup script for Vietnam deployment

BACKUP_DIR="/var/backups/acb-banking"
DATE=$(date +%Y%m%d_%H%M%S)
APP_DIR="/var/www/acb-banking"

mkdir -p $BACKUP_DIR

echo "Starting backup at $(date)"

# Backup application files
tar -czf $BACKUP_DIR/acb-banking-$DATE.tar.gz \
    --exclude=node_modules \
    --exclude=logs \
    $APP_DIR

# Backup nginx config
sudo cp /etc/nginx/nginx.conf $BACKUP_DIR/nginx-$DATE.conf

# Backup PM2 config
pm2 save --force 2>/dev/null || true
cp ~/.pm2/dump.pm2 $BACKUP_DIR/pm2-$DATE.json 2>/dev/null || true

# Backup SSL certificates
sudo tar -czf $BACKUP_DIR/ssl-$DATE.tar.gz /etc/letsencrypt 2>/dev/null || true

# Keep only last 7 backups
find $BACKUP_DIR -name "acb-banking-*.tar.gz" -mtime +7 -delete
find $BACKUP_DIR -name "nginx-*.conf" -mtime +7 -delete
find $BACKUP_DIR -name "pm2-*.json" -mtime +7 -delete
find $BACKUP_DIR -name "ssl-*.tar.gz" -mtime +7 -delete

echo "Backup completed: $BACKUP_DIR/acb-banking-$DATE.tar.gz"
EOL
    
    chmod +x backup.sh
    
    # Create monitoring script
    cat > monitor.sh << 'EOL'
#!/bin/bash
# Enhanced monitoring script for Vietnam deployment

LOG_FILE="/var/log/acb-monitor.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

# Check application status
if command -v pm2 >/dev/null 2>&1; then
    PM2_STATUS=$(pm2 jlist 2>/dev/null | jq -r '.[0].pm2_env.status' 2>/dev/null || echo "unknown")
    APP_MEMORY=$(pm2 jlist 2>/dev/null | jq -r '.[0].monit.memory' 2>/dev/null || echo "0")
    APP_CPU=$(pm2 jlist 2>/dev/null | jq -r '.[0].monit.cpu' 2>/dev/null || echo "0")
else
    PM2_STATUS="not_installed"
    APP_MEMORY="0"
    APP_CPU="0"
fi

# System stats
DISK_USAGE=$(df -h / | awk 'NR==2{print $5}' | sed 's/%//')
MEMORY_USAGE=$(free | grep Mem | awk '{printf("%.2f", $3/$2 * 100.0)}')
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}' 2>/dev/null || echo "0")

# Network check
NETWORK_OK="true"
if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
    NETWORK_OK="false"
fi

echo "[$DATE] Status: $PM2_STATUS, Memory: ${APP_MEMORY}B, CPU: $APP_CPU%, Disk: $DISK_USAGE%, System Memory: $MEMORY_USAGE%, System CPU: $CPU_USAGE%, Network: $NETWORK_OK" >> $LOG_FILE

# Alerts for Vietnam conditions
if (( $(echo "$MEMORY_USAGE > 80" | bc -l 2>/dev/null || echo "0") )); then
    echo "[$DATE] HIGH MEMORY USAGE ALERT: $MEMORY_USAGE%" >> $LOG_FILE
fi

if [ "$DISK_USAGE" -gt 85 ]; then
    echo "[$DATE] HIGH DISK USAGE ALERT: $DISK_USAGE%" >> $LOG_FILE
fi

if [ "$NETWORK_OK" = "false" ]; then
    echo "[$DATE] NETWORK CONNECTIVITY ALERT" >> $LOG_FILE
fi
EOL
    
    chmod +x monitor.sh
    
    # Setup cron jobs
    (crontab -l 2>/dev/null; cat << 'EOL'
# ACB Banking automated tasks
*/5 * * * * /var/www/acb-banking/monitor.sh
0 2 * * * /var/www/acb-banking/backup.sh
0 0 * * * /usr/bin/certbot renew --quiet
EOL
    ) | crontab -
    
    print_status "Monitoring and automation configured"
}

# Function to apply Vietnam-specific optimizations
apply_vn_optimizations() {
    print_step "Applying Vietnam-specific optimizations..."
    
    # Set Vietnam timezone
    sudo timedatectl set-timezone Asia/Ho_Chi_Minh
    
    # Optimize sysctl for Vietnam network conditions
    sudo tee -a /etc/sysctl.conf << EOL

# Vietnam VPS optimizations
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 5000
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_keepalive_time = 300
net.ipv4.tcp_keepalive_probes = 3
net.ipv4.tcp_keepalive_intvl = 30
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_tw_reuse = 1
vm.swappiness = 10
vm.dirty_ratio = 15
vm.dirty_background_ratio = 5
EOL
    
    sudo sysctl -p
    
    # Optimize for Vietnamese users
    echo "en_US.UTF-8 UTF-8" | sudo tee -a /etc/locale.gen
    sudo locale-gen
    
    # Set ulimits
    echo "$CURRENT_USER soft nofile 65535" | sudo tee -a /etc/security/limits.conf
    echo "$CURRENT_USER hard nofile 65535" | sudo tee -a /etc/security/limits.conf
    
    print_status "Vietnam optimizations applied"
}

# Function to perform final verification
final_verification() {
    print_step "Performing final verification..."
    
    local all_checks_passed=true
    
    # Check PM2
    if pm2 list | grep -q "online"; then
        print_status "✅ PM2 application is running"
    else
        print_error "❌ PM2 application is not running"
        all_checks_passed=false
    fi
    
    # Check Nginx
    if sudo systemctl is-active --quiet nginx; then
        print_status "✅ Nginx is running"
    else
        print_error "❌ Nginx is not running"
        all_checks_passed=false
    fi
    
    # Check application health
    sleep 3
    if curl -s --max-time 10 http://localhost:3000/health > /dev/null; then
        print_status "✅ Application health check passed"
    else
        print_warning "⚠️  Application health check failed (may need time to start)"
    fi
    
    # Check firewall
    if sudo ufw status | grep -q "Status: active"; then
        print_status "✅ Firewall is active"
    else
        print_warning "⚠️  Firewall status unclear"
    fi
    
    # Check fail2ban
    if sudo systemctl is-active --quiet fail2ban; then
        print_status "✅ Fail2ban is running"
    else
        print_warning "⚠️  Fail2ban may not be running"
    fi
    
    return $all_checks_passed
}

# Function to display final summary
display_summary() {
    local server_ip=$(curl -s --max-time 5 ifconfig.me 2>/dev/null || echo "Unknown")
    
    echo ""
    print_success "🎉 ACB Banking Production Deployment Completed!"
    echo ""
    echo "=================================================================="
    echo "🏦 ACB Banking - Production Ready for Vietnam VPS"
    echo "=================================================================="
    echo ""
    print_info "🌐 Server Information:"
    echo "  Server IP: $server_ip"
    echo "  Domain: $DOMAIN"
    echo "  Location: Vietnam"
    echo "  Timezone: $(timedatectl | grep 'Time zone' | awk '{print $3}')"
    echo ""
    print_info "🔧 Application URLs:"
    echo "  🏠 Dashboard: https://$DOMAIN (Login required)"
    echo "  📱 QR Payment: https://$DOMAIN/qr-thanh-toan (Public)"
    echo "  📊 Health Check: https://$DOMAIN/health"
    echo ""
    print_info "🔑 Login Credentials:"
    echo "  Username: lethuan431"
    echo "  Password: ThuanDayNe@201019"
    echo ""
    print_info "🛠️ Management Commands:"
    echo "  ./status.sh              - Check system status"
    echo "  ./backup.sh              - Manual backup"
    echo "  pm2 status               - PM2 status"
    echo "  pm2 logs                 - View logs"
    echo "  pm2 restart acb-banking  - Restart app"
    echo ""
    print_info "🇻🇳 Vietnam Optimizations:"
    echo "  ✅ Vietnam NPM mirrors configured"
    echo "  ✅ Asia/Ho_Chi_Minh timezone set"
    echo "  ✅ Vietnam IP ranges whitelisted"
    echo "  ✅ Network optimized for VN conditions"
    echo ""
    print_info "🔐 Security Features:"
    echo "  ✅ UFW Firewall active"
    echo "  ✅ Fail2ban protection"
    echo "  ✅ SSL/TLS encryption"
    echo "  ✅ Rate limiting enabled"
    echo "  ✅ Security headers active"
    echo ""
    print_info "📊 Monitoring:"
    echo "  ✅ Health monitoring (every 5 min)"
    echo "  ✅ Daily backups (2 AM)"
    echo "  ✅ SSL auto-renewal"
    echo "  ✅ Log rotation"
    echo ""
    print_warning "🚨 Next Steps:"
    echo "  1. Update DNS A record: $DOMAIN -> $server_ip"
    echo "  2. Test SSL: https://$DOMAIN"
    echo "  3. Monitor: ./status.sh"
    echo ""
    print_success "🎯 Deployment completed successfully for Vietnam VPS!"
    echo "=================================================================="
}

# Main deployment flow
main() {
    print_step "🚀 Starting fully automated Vietnam VPS deployment..."
    
    # Handle user setup (root detection)
    setup_user
    
    # Core system setup
    update_system
    install_dependencies
    install_nodejs
    install_pm2
    
    # Application setup
    setup_application
    install_npm_dependencies
    build_application
    setup_environment
    
    # Service configuration
    configure_pm2
    configure_nginx
    configure_security
    setup_ssl
    
    # Automation and monitoring
    setup_automation
    apply_vn_optimizations
    
    # Final verification and summary
    if final_verification; then
        display_summary
        exit 0
    else
        print_error "Some checks failed, but deployment may still be functional"
        display_summary
        exit 1
    fi
}

# Run main function
main "$@" 