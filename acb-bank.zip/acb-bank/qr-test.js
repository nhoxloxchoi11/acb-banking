const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const { ACB } = require('./dist/ACB');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
            scriptSrc: ["'self'", "'unsafe-inline'"],
            fontSrc: ["'self'", "https://cdnjs.cloudflare.com"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'"]
        }
    }
}));

// Compression middleware
app.use(compression());

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
});

const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // limit each IP to 5 auth requests per windowMs
    message: 'Too many authentication attempts, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
});

app.use(limiter);

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'acb-banking-secret-key-2024-production',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        sameSite: 'strict'
    },
    name: 'acb-session'
}));

// Static files with caching
app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: NODE_ENV === 'production' ? '1d' : '0',
    etag: true,
    lastModified: true
}));

// User credentials (In production, use database)
const users = {
    'lethuan431': {
        password: '$2b$10$NoTDRYwOVzW/g/G9oO0.ne1HmsvhnWk60Sb/R4pFrcT5UP.AwVNaC', // ThuanDayNe@201019
        username: 'lethuan431'
    }
};

// Authentication middleware
function requireAuth(req, res, next) {
    if (req.session && req.session.isAuthenticated) {
        return next();
    } else {
        return res.status(401).json({
            success: false,
            message: 'Unauthorized - Please login first',
            redirectTo: '/login'
        });
    }
}

function requireAuthPage(req, res, next) {
    if (req.session && req.session.isAuthenticated) {
        return next();
    } else {
        return res.redirect('/login');
    }
}

// ACB client with error handling
let acbClient;
try {
    const credentials = {
        username: process.env.ACB_USERNAME || '11381077',
        password: process.env.ACB_PASSWORD || 'ThuanDayNe@201019'
    };
    acbClient = new ACB(credentials);
    console.log('✅ ACB client initialized successfully');
} catch (error) {
    console.error('❌ Failed to initialize ACB client:', error);
}

// Authentication Routes
app.get('/login', (req, res) => {
    if (req.session && req.session.isAuthenticated) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'public/login.html'));
});

app.post('/api/login', authLimiter, async (req, res) => {
    try {
        const { username, password } = req.body;
        
        // Input validation
        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: 'Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu'
            });
        }

        // Additional input sanitization
        const sanitizedUsername = username.toString().trim().slice(0, 50);

        const user = users[sanitizedUsername];
        if (!user) {
            // Add delay to prevent timing attacks
            await new Promise(resolve => setTimeout(resolve, 1000));
            return res.status(401).json({
                success: false,
                message: 'Tên đăng nhập hoặc mật khẩu không đúng'
            });
        }

        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.status(401).json({
                success: false,
                message: 'Tên đăng nhập hoặc mật khẩu không đúng'
            });
        }

        // Regenerate session ID after successful login
        req.session.regenerate((err) => {
            if (err) {
                console.error('Session regeneration error:', err);
                return res.status(500).json({
                    success: false,
                    message: 'Lỗi hệ thống'
                });
            }

            req.session.userId = sanitizedUsername;
            req.session.username = user.username;
            req.session.isAuthenticated = true;
            req.session.loginTime = new Date().toISOString();

            res.json({
                success: true,
                message: 'Đăng nhập thành công',
                user: {
                    username: user.username
                }
            });
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Lỗi server khi đăng nhập'
        });
    }
});

app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
            return res.status(500).json({
                success: false,
                message: 'Lỗi khi đăng xuất'
            });
        }
        
        res.clearCookie('acb-session');
        res.json({
            success: true,
            message: 'Đăng xuất thành công'
        });
    });
});

app.get('/api/auth-status', (req, res) => {
    if (req.session && req.session.isAuthenticated) {
        res.json({
            isAuthenticated: true,
            username: req.session.username,
            loginTime: req.session.loginTime
        });
    } else {
        res.json({
            isAuthenticated: false
        });
    }
});

// Protected API Routes with improved error handling
app.get('/api/balance', requireAuth, async (req, res) => {
    try {
        if (!acbClient) {
            return res.status(503).json({
                success: false,
                message: 'Dịch vụ ngân hàng tạm thời không khả dụng'
            });
        }

        console.log('📊 Đang lấy thông tin số dư...');
        const balanceInfo = await Promise.race([
            acbClient.getBalance(),
            new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Timeout')), 30000)
            )
        ]);
        
        // Remove debug logs in production
        if (NODE_ENV === 'development') {
            console.log('Raw balance data:', JSON.stringify(balanceInfo, null, 2));
        }
        
        if (balanceInfo) {
            // Transform data to ensure proper format
            let transformedData = balanceInfo;
            
            // If balanceInfo is an array, wrap it in an object
            if (Array.isArray(balanceInfo)) {
                transformedData = { balances: balanceInfo };
            }
            
            // If balanceInfo doesn't have balances property, create it
            if (balanceInfo && !balanceInfo.balances && balanceInfo.accountNumber) {
                transformedData = { balances: [balanceInfo] };
            }
            
            // Ensure numeric values
            if (transformedData.balances && Array.isArray(transformedData.balances)) {
                transformedData.balances = transformedData.balances.map(balance => ({
                    accountNumber: balance.accountNumber || '11381077',
                    accountOwner: balance.ownerName || balance.accountOwner || balance.owner || 'Không xác định',
                    accountDescription: balance.accountDescription || '',
                    currency: balance.currency || 'VND',
                    availableBalance: parseFloat(balance.balance) || parseFloat(balance.availableBalance) || 0,
                    currentBalance: parseFloat(balance.totalBalance) || parseFloat(balance.currentBalance) || parseFloat(balance.balance) || 0,
                    status: balance.status || 1
                }));
            }
            
            // Remove debug logs in production
            if (NODE_ENV === 'development') {
                console.log('Transformed balance data:', JSON.stringify(transformedData, null, 2));
            }
            
            res.json({
                success: true,
                data: transformedData,
                timestamp: new Date().toISOString()
            });
        } else {
            res.status(404).json({
                success: false,
                message: 'Không thể lấy thông tin số dư'
            });
        }
    } catch (error) {
        console.error('Lỗi API balance:', error);
        
        let message = 'Lỗi server khi lấy số dư';
        if (error.message === 'Timeout') {
            message = 'Kết nối tới ngân hàng bị timeout';
        }
        
        res.status(500).json({
            success: false,
            message,
            error: NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

app.get('/api/transactions/:accountNumber', requireAuth, async (req, res) => {
    try {
        if (!acbClient) {
            return res.status(503).json({
                success: false,
                message: 'Dịch vụ ngân hàng tạm thời không khả dụng'
            });
        }

        const { accountNumber } = req.params;
        const rows = Math.min(parseInt(req.query.rows) || 20, 100); // Limit max rows
        
        // Validate account number format
        if (!/^\d{6,20}$/.test(accountNumber)) {
            return res.status(400).json({
                success: false,
                message: 'Số tài khoản không hợp lệ'
            });
        }
        
        console.log(`📈 Đang lấy lịch sử giao dịch cho tài khoản ${accountNumber}...`);
        
        const transactions = await Promise.race([
            acbClient.getTransactionsHistory({
                rows,
                accountNumber
            }),
            new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Timeout')), 30000)
            )
        ]);
        
        if (transactions) {
            res.json({
                success: true,
                data: transactions,
                count: transactions.length,
                timestamp: new Date().toISOString()
            });
        } else {
            res.status(404).json({
                success: false,
                message: 'Không thể lấy lịch sử giao dịch'
            });
        }
    } catch (error) {
        console.error('Lỗi API transactions:', error);
        
        let message = 'Lỗi server khi lấy lịch sử giao dịch';
        if (error.message === 'Timeout') {
            message = 'Kết nối tới ngân hàng bị timeout';
        }
        
        res.status(500).json({
            success: false,
            message,
            error: NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Protected Pages
app.get('/', requireAuthPage, (req, res) => {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Public Pages
app.get('/qr-thanh-toan', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/qr-payment.html'));
});

// Health check
app.get('/health', (req, res) => {
    const health = {
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: NODE_ENV,
        memory: process.memoryUsage(),
        version: process.version
    };
    
    res.json(health);
});

// Public API for QR Payment verification (limited functionality)
app.get('/api/public/transactions/verify', async (req, res) => {
    try {
        const { accountNumber, amount, description, timeWindow } = req.query;
        
        if (!accountNumber || !amount || !description) {
            return res.status(400).json({
                success: false,
                message: 'Missing required parameters'
            });
        }

        if (!acbClient) {
            return res.status(503).json({
                success: false,
                message: 'Dịch vụ ngân hàng tạm thời không khả dụng'
            });
        }

        console.log(`🔍 Public API: Verifying payment for ${accountNumber}, amount: ${amount}, description: ${description}`);
        
        const transactions = await Promise.race([
            acbClient.getTransactionsHistory({
                rows: 10, // Limited to recent 10 transactions for security
                accountNumber
            }),
            new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Timeout')), 30000)
            )
        ]);
        
        if (transactions) {
            // Filter for matching transaction
            const matchedTransaction = transactions.find(transaction => {
                const transactionDesc = transaction.description.toLowerCase();
                const searchDesc = description.toLowerCase();
                const amountMatch = transaction.amount >= parseInt(amount);
                const typeMatch = transaction.type === 'IN';
                const descMatch = transactionDesc.includes(searchDesc);
                
                // Check if transaction is recent (within timeWindow or last 24 hours)
                const transactionTime = new Date(transaction.activeDatetime);
                const now = new Date();
                const timeDiff = now - transactionTime;
                const maxAge = parseInt(timeWindow) || (24 * 60 * 60 * 1000); // 24 hours default
                
                return typeMatch && amountMatch && descMatch && timeDiff <= maxAge;
            });
            
            if (matchedTransaction) {
                res.json({
                    success: true,
                    verified: true,
                    transaction: {
                        amount: matchedTransaction.amount,
                        description: matchedTransaction.description,
                        date: matchedTransaction.activeDatetime,
                        transactionNumber: matchedTransaction.transactionNumber
                    }
                });
            } else {
                res.json({
                    success: true,
                    verified: false,
                    message: 'Không tìm thấy giao dịch phù hợp'
                });
            }
        } else {
            res.status(404).json({
                success: false,
                message: 'Không thể lấy lịch sử giao dịch'
            });
        }
    } catch (error) {
        console.error('Lỗi API public transactions verify:', error);
        
        let message = 'Lỗi server khi kiểm tra giao dịch';
        if (error.message === 'Timeout') {
            message = 'Kết nối tới ngân hàng bị timeout';
        }
        
        res.status(500).json({
            success: false,
            message,
            error: NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Endpoint not found',
        path: req.originalUrl
    });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    
    res.status(500).json({
        success: false,
        message: 'Internal server error',
        error: NODE_ENV === 'development' ? err.message : undefined
    });
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received. Shutting down gracefully...');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT received. Shutting down gracefully...');
    process.exit(0);
});

const server = app.listen(PORT, () => {
    console.log('🚀 ACB Banking Web App đã khởi động!');
    console.log(`🌐 Environment: ${NODE_ENV}`);
    console.log(`🌐 Truy cập: http://localhost:${PORT}/login`);
    console.log(`📊 API Health: http://localhost:${PORT}/health`);
    console.log('\n🔑 Thông tin đăng nhập:');
    console.log('   Username: lethuan431');
    console.log('   Password: ThuanDayNe@201019');
    console.log('\n🛡️  Security features enabled:');
    console.log('   ✅ Rate limiting');
    console.log('   ✅ Helmet security headers');
    console.log('   ✅ Session security');
    console.log('   ✅ Input validation');
    console.log('   ✅ Compression');
});

module.exports = app; 