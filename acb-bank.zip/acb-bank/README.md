# 🏦 ACB Banking - Production Ready for Vietnam VPS

> 🚀 **Fully Automated Deployment** for `thuanday.io.vn` - Secure ACB Banking Web Application

[![Domain](https://img.shields.io/badge/domain-thuanday.io.vn-blue.svg)](https://thuanday.io.vn)
[![SSL](https://img.shields.io/badge/SSL-enabled-green.svg)](https://thuanday.io.vn)
[![Node.js](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen)](https://nodejs.org/)
[![Production](https://img.shields.io/badge/production-ready-success.svg)](https://thuanday.io.vn)
[![Vietnam](https://img.shields.io/badge/optimized-Vietnam%20VPS-red.svg)](https://thuanday.io.vn)

## 📋 Overview

Production-ready ACB Banking Web Application deployed at `thuanday.io.vn` với:

- 🔐 **Secure Authentication** - Session-based login protection
- 💰 **Real-time Balance** - Live ACB account information
- 📱 **Public QR Payment** - No authentication required
- 🛡️ **Enterprise Security** - SSL, rate limiting, intrusion prevention
- ⚡ **High Performance** - PM2 cluster, Nginx optimization
- 📊 **Monitoring** - Health checks, automated backups
- 🇻🇳 **Vietnam Optimized** - Fastest registries, local mirrors, timezone

## 🌐 Live Application

- **🏠 Dashboard:** https://thuanday.io.vn (Login required)
- **📱 QR Payment:** https://thuanday.io.vn/qr-thanh-toan (Public access)
- **📊 Health Check:** https://thuanday.io.vn/health

## 🔑 Access Credentials

```
Username: lethuan431
Password: ThuanDayNe@201019
```

## 🚀 One-Command Installation

### ⚡ Super Simple - Just One Command!

```bash
# 1. Upload files to your Vietnam VPS
# 2. Run the installer
chmod +x install.sh && ./install.sh
```

**That's it!** The script will automatically:
- ✅ Check system requirements
- ✅ Install Node.js, PM2, Nginx
- ✅ Configure SSL certificate
- ✅ Set up firewall and security
- ✅ Optimize for Vietnam networks
- ✅ Start all services

### 🇻🇳 Vietnam VPS Specific Instructions

#### For Popular Vietnam Hosting Providers:

**1. Bizfly Cloud:**
```bash
# After creating Ubuntu VPS
ssh root@your-server-ip
git clone https://github.com/your-repo/acb-banking.git
cd acb-banking
./install.sh
```

**2. VNG Cloud:**
```bash
# Connect to your instance
ssh ubuntu@your-server-ip
sudo su -
git clone https://github.com/your-repo/acb-banking.git
cd acb-banking
./install.sh
```

**3. VNPT Cloud:**
```bash
# SSH to server
ssh root@your-server-ip
# Upload project files or git clone
./install.sh
```

## 🔧 Alternative Installation Methods

### Manual Step-by-Step (if you prefer control)

```bash
# 1. Pre-deployment check
chmod +x pre-deploy-check.sh
./pre-deploy-check.sh

# 2. Main deployment (if checks pass)
chmod +x deploy-ubuntu.sh
./deploy-ubuntu.sh
```

### Docker Deployment (Alternative)

```bash
# Build and run with Docker
docker build -t acb-banking .
docker-compose up -d
```

## 🇻🇳 Vietnam Optimizations

### Network Optimizations
- **NPM Registry:** Automatically selects fastest Vietnam mirror
- **Ubuntu Mirrors:** Uses `vn.archive.ubuntu.com` for faster downloads
- **Timezone:** Set to `Asia/Ho_Chi_Minh`
- **DNS:** Optimized for Vietnam ISPs

### Supported Vietnam ISPs
- ✅ Viettel (1.52.0.0/14)
- ✅ VNPT (14.160.0.0/11)  
- ✅ FPT Telecom (27.64.0.0/13)
- ✅ All major Vietnam providers

### Registry Priority for Vietnam
1. 🥇 `registry.npmmirror.com` (China CDN - fastest for VN)
2. 🥈 `r.cnpmjs.org` (Alibaba mirror)
3. 🥉 `registry.npm.taobao.org` (Taobao mirror)
4. 🏃 `npmreg.proxy.ustclug.org` (University mirror)
5. 🐌 `registry.npmjs.org` (Official - fallback)

## 📁 Project Structure

```
acb-banking/
├── install.sh               # 🚀 ONE-COMMAND INSTALLER
├── pre-deploy-check.sh      # ✅ Pre-deployment validation
├── deploy-ubuntu.sh         # 🔧 Main deployment script
├── qr-test.js              # 💻 Main production server
├── package.json            # 📦 Production dependencies
├── ecosystem.config.js     # ⚙️  PM2 configuration
├── nginx.conf              # 🌐 Nginx configuration
├── production.env          # 🔧 Environment template
├── public/                 # 🎨 Frontend assets
│   ├── index.html          # 🏠 Dashboard (protected)
│   ├── qr-payment.html     # 📱 QR payment (public)
│   └── *.css, *.js         # 🎨 Optimized assets
├── status.sh               # 📊 Status monitoring
└── backup.sh               # 💾 Backup automation
```

## 🔧 Post-Installation

### Immediate Tasks (After Installation)
```bash
# 1. Check system status
./status.sh

# 2. View application logs
pm2 logs

# 3. Test application
curl http://localhost:3000/health
```

### DNS Configuration
Update your domain DNS settings:
```
Type: A
Name: thuanday.io.vn
Value: YOUR_VPS_IP

Type: A  
Name: www
Value: YOUR_VPS_IP
```

### SSL Certificate
SSL is configured automatically, but verify:
```bash
# Check SSL status
sudo certbot certificates

# Test SSL
curl -I https://thuanday.io.vn
```

## 📊 API Endpoints

### Public Endpoints (No Authentication)
- `GET /qr-thanh-toan` - QR payment page
- `GET /api/public/transactions/verify` - Payment verification
- `GET /health` - Health check
- `POST /api/login` - Authentication

### Protected Endpoints (Login Required)
- `GET /` - Main dashboard
- `GET /api/balance` - Account balance
- `GET /api/transactions/:accountNumber` - Transaction history
- `POST /api/logout` - Logout

## 🛠️ Management Commands

```bash
# Application Management
./status.sh                   # Overall system status
pm2 status                    # PM2 process status
pm2 logs                      # View application logs
pm2 restart acb-banking       # Restart application
pm2 monit                     # Real-time monitoring

# Server Management
sudo systemctl status nginx   # Nginx status
sudo nginx -t                 # Test Nginx config
sudo systemctl reload nginx   # Reload Nginx

# Security & Monitoring
sudo ufw status               # Firewall status
sudo fail2ban-client status   # Intrusion prevention
./backup.sh                   # Manual backup

# SSL Management
sudo certbot certificates     # Check SSL status
sudo certbot renew           # Manual SSL renewal
```

## 🛡️ Security Features

### Automatic Security Configuration
- ✅ **UFW Firewall** - Only allow SSH, HTTP, HTTPS
- ✅ **Fail2ban** - Block malicious IPs automatically
- ✅ **SSL/TLS** - Let's Encrypt certificate with auto-renewal
- ✅ **Rate Limiting** - API and authentication protection
- ✅ **Security Headers** - HSTS, CSP, X-Frame-Options
- ✅ **Session Security** - Secure cookies, bcrypt passwords

### Vietnam ISP Whitelist
Automatic whitelist for major Vietnam ISPs:
- Viettel Networks
- VNPT Internet
- FPT Telecom
- Local development IPs

## 📈 Performance Optimizations

### Vietnam-Specific Optimizations
- **Package Installation:** Fastest mirrors auto-selected
- **Network Settings:** Optimized for Vietnam latency
- **Timezone:** Asia/Ho_Chi_Minh for accurate logging
- **Registry Speed Test:** Real-time speed testing
- **Connection Pooling:** Optimized for Vietnam networks

### System Optimizations
- **PM2 Cluster:** Multi-core utilization
- **Nginx Gzip:** Level 6 compression
- **Static Caching:** 1-year browser cache
- **Keep-Alive:** Persistent connections
- **Memory Management:** 512MB limit with auto-restart

## 🔄 Backup & Recovery

### Automated Backups
```bash
# Daily backups at 2 AM (Vietnam time)
# Retention: 7 days
# Includes: App + Config + SSL + PM2 state
```

### Manual Backup
```bash
./backup.sh
# Creates: /var/backups/acb-banking/acb-banking-YYYYMMDD_HHMMSS.tar.gz
```

### Recovery Process
```bash
# 1. Stop services
pm2 stop all && sudo systemctl stop nginx

# 2. Restore from backup
cd /var/backups/acb-banking
tar -xzf acb-banking-latest.tar.gz -C /var/www/

# 3. Restart services  
pm2 start all && sudo systemctl start nginx
```

## 📞 Troubleshooting

### Common Issues & Solutions

**1. npm timeout errors:**
```bash
# The installer automatically handles this, but if manual fix needed:
npm config set registry https://registry.npmmirror.com/
npm config set timeout 300000
```

**2. SSL certificate issues:**
```bash
# Automatic retry is built-in, but for manual fix:
sudo certbot --nginx -d thuanday.io.vn
```

**3. Application not starting:**
```bash
# Check logs and restart
pm2 logs acb-banking
pm2 restart acb-banking
```

**4. Nginx configuration errors:**
```bash
# Test and reload config
sudo nginx -t
sudo systemctl reload nginx
```

### Emergency Recovery
```bash
# If everything breaks, re-run installer
./install.sh

# Or step by step
./pre-deploy-check.sh
./deploy-ubuntu.sh
```

### Support Information
- **Technical Issues:** Check `./status.sh` output
- **Performance Issues:** Run `pm2 monit`
- **Security Issues:** Check `sudo fail2ban-client status`
- **SSL Issues:** Run `sudo certbot certificates`

## 🔐 Security Checklist

- [x] SSL/TLS certificate (Let's Encrypt with auto-renewal)
- [x] UFW firewall enabled and configured
- [x] Fail2ban intrusion prevention active
- [x] Strong session secrets (auto-generated)
- [x] Rate limiting on all endpoints
- [x] Security headers (Helmet.js)
- [x] Regular security updates (unattended-upgrades)
- [x] Access logs monitored
- [x] Backup strategy implemented
- [x] Vietnam ISP optimization
- [x] Network timeout handling
- [x] Error handling and recovery

## 🎯 Quick Start Summary

**For immediate deployment on Vietnam VPS:**

1. **Upload project to VPS**
2. **Run installer:** `./install.sh` 
3. **Update DNS:** Point `thuanday.io.vn` to your VPS IP
4. **Access application:** https://thuanday.io.vn

**Login:** `lethuan431` / `ThuanDayNe@201019`

---

**🎉 ACB Banking Production Environment**

*Fully automated deployment optimized for Vietnam VPS infrastructure*

**Live at:** https://thuanday.io.vn

**One command to rule them all:** `./install.sh` 🚀
